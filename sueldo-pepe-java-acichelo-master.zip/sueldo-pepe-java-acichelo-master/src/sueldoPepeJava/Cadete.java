package sueldoPepeJava;

public class Cadete implements Categoria {
	public int sueldoNeto() {
		return 20000;
	}
}