package sueldoPepeJava;

public class Gerente implements Categoria {
	public int sueldoNeto() {
		return 15000;
	}
}
