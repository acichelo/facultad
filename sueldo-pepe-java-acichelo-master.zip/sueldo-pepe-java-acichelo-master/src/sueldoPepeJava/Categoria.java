package sueldoPepeJava;

public interface Categoria {
	public int sueldoNeto();
}
